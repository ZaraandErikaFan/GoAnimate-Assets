Comedy World Custom Clothing: Adam Long-Sleeved T-Shirt
Created by JackTheVyonder2006

--HOW TO INSTALL--

1. Extract the adam_a0xx folder from the ZIP folder to 
(location of your wrapper folder)/wrappr-offline/server/store/3a981f5cb2739137/cc_store/family/upper_body

2. Rename the adam_a0xx folder to any number that has not been used yet. MAKE SURE TO KEEP THE "ADAM_" PART!

3. Go to the family folder and open cc_theme.xml with Notepad or any program that can edit XML files.

4. Scroll down until you find one of the following:
		<component type="upper_body" id="adam_0xx" path="adam_0xx" name="adam_0xx" thumb="thumbnail.swf" display_order="100" money="0" sharing="0" enable="Y">
			<state id="chuckle" filename="chuckle.swf"/>
			<state id="crossed_arms" filename="crossed_arms.swf"/>
			<state id="dance" filename="dance.swf"/>
			<state id="default" filename="default.swf"/>
			<state id="excited" filename="excited.swf"/>
			<state id="fearful" filename="fearful.swf"/>
			<state id="kneel_down" filename="kneel_down.swf"/>
			<state id="laugh" filename="laugh.swf"/>
			<state id="lie_down" filename="lie_down.swf"/>
			<state id="point_at" filename="point_at.swf"/>
			<state id="run" filename="run.swf"/>
			<state id="sad" filename="sad.swf"/>
			<state id="sit" filename="sit.swf"/>
			<state id="talk" filename="talk.swf"/>
			<state id="talk_on_phone" filename="talk_on_phone.swf"/>
			<state id="taunt" filename="taunt.swf"/>
			<state id="walk" filename="walk.swf"/>
		</component>
5. Copy the whole component, create a new line, and replace the "xx" with the number you set the Long-Sleeved T-Shirt folder to.

6. You're done! Go to the Character Creator on Wrapper online and the Long-Sleeved T-Shirt should be there!

If you have any issues, contact me on discord: JackTheVyonder2006#3431